<?php include("head-menu.php") ?>
<div class="mdui-container" style="margin:auto;overflow:auto;">


    <div class="mdui-text-color-black  ">
        <br>
        <div class="mdui-container">
            
        <?php include("get-sql-article-of-category.php") ?>   
    </div>

</div>
<?php include("login-logon-onload.php") ?>