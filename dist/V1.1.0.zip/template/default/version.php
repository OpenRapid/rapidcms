<?php
$infor["name"]="默认主题";
$infor["version"]="1.0.2";
$infor["author"]="RapidTeam";
?>