<div style="color:black;" class="mdui-drawer mdui-drawer-open mc-drawer" id="drawer">
        <ul class="mdui-list">
            <a href="index.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe88a;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">首页</div>
                </li>
            </a>
            <div class="mdui-divider"></div>
            <a href="setting.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe8b8;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">基本设置</div>
                </li>
            </a>
            <a href="user.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe853;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">用户</div>
                </li>
            </a>
            <a href="category.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe5c3;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">分类</div>
                </li>
            </a>
            <a href="article.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe06c;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">文章</div>
                </li>
            </a>
            <a href="temp.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xeb3f;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">模板</div>
                </li>
            </a>
            <div class="mdui-divider"></div>
            <a href="update.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe8d7;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">检查更新</div>
                </li>
            </a>
            <a href="about.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe147;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">关于</div>
                </li>
            </a>
        </ul>
        <div class="mdui-typo" style=" position: absolute;bottom:0%;   box-sizing: border-box; width: 100%;  padding: 20px 16px;">
            <h4> <small>© 2023 RapidTeam</small><br> <small>Powered by RapidTeam
                </small></h4>
        </div>
    </div>